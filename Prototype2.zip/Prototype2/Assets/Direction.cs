﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public enum Direction { Right, Up, Down, Left, None };
